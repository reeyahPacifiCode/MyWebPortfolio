console.log("heow");
console.warn("warning");
console.error("error");